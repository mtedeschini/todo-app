<template>
        <div class=" container text-center mt-2">
            <div class="spinner-border text-light " role="status" aria-hidden="true"></div>
        </div>
</template>

<style scoped>
    .navbar{
        min-height: 60px;
    }
</style>


